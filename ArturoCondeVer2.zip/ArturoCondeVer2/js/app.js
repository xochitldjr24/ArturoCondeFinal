window.addEventListener('load', function(){/*cuando la pagina cargue le manda un evento */
	//OWL CAROSEL
$(document).ready(function() {

    "use strict";
    
    $(".owl-demo").owlCarousel({
        autoPlay: 100000000,
        items: 3, //10 items above 1000px browser width
        itemsDesktop: [1370, 3], //5 items between 1000px and 901px
        itemsDesktopSmall: [900, 1], // betweem 900px and 601px
        itemsTablet: [600, 1], //2 items between 600 and 0
    });
});
	 

});

